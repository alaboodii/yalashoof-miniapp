import asyncio
import json
import logging
import os
import sys
from pathlib import Path

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart
from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
    WebAppInfo,
)
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
WEBAPP_URL = os.getenv("WEBAPP_URL")
DEV_URL = os.getenv("DEV_URL", "").strip()

if not BOT_TOKEN:
    sys.exit("BOT_TOKEN missing.")
if not WEBAPP_URL or not WEBAPP_URL.startswith("https://"):
    sys.exit("WEBAPP_URL missing or not HTTPS.")

USERS_FILE = Path(__file__).resolve().parent / "users.json"


def load_users() -> set[int]:
    if USERS_FILE.exists():
        try:
            return set(json.loads(USERS_FILE.read_text(encoding="utf-8")))
        except Exception:
            return set()
    return set()


def save_users(users: set[int]) -> None:
    tmp = USERS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(sorted(users)), encoding="utf-8")
    tmp.replace(USERS_FILE)


users: set[int] = load_users()

dp = Dispatcher()


def build_welcome() -> str:
    return (
        "⚽️ مرحباً بك في بوت نقل المباريات\n\n"
        "📺 يمكنك مشاهدة:\n"
        "• المباريات العالمية\n"
        "• المباريات العربية\n"
        "• البث المباشر\n\n"
        "🔴 اضغط الزر بالاسفل لمشاهدة المباريات"
    )


def build_keyboard() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(
            text="مشاهدة المباريات المباشرة ⚽️",
            web_app=WebAppInfo(url=WEBAPP_URL),
        )]
    ]
    if DEV_URL:
        rows.append([InlineKeyboardButton(text="Dev", url=DEV_URL)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


@dp.message(CommandStart())
async def on_start(message: Message) -> None:
    if message.from_user:
        uid = message.from_user.id
        if uid not in users:
            users.add(uid)
            save_users(users)
    await message.answer(build_welcome(), reply_markup=build_keyboard())


async def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )
    bot = Bot(
        token=BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        await bot.session.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logging.info("Bot stopped.")
